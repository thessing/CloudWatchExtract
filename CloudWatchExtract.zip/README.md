# CloudWatchExtract
Automatically Extract CloudWatch Logs to S3
